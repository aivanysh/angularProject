import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent }           from './dashboard.component';
import { ExternalComponent }  from './external/external.component';
import { InboxComponent }    from './external/inbox/inbox.component';

const adminRoutes: Routes = [
  {
    path: 'Dashboard',
    component: DashboardComponent,
    children: [
      {
        path: '',
        children: [
          { path: 'InboxComponent', component: InboxComponent },
          { path: '', component: ExternalComponent }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(adminRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DashboardRoutingModule {}
