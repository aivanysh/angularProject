import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule, MatCheckboxModule } from '@angular/material';
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatTableModule} from '@angular/material/table';
import { MatPaginatorModule} from '@angular/material/paginator';
import { AppRoutingModule } from '../app-routing.module';
// import { DashboardRoutingModule } from './dashboard-routing.module';
import { SharableModule } from '../sharable/sharable.module';
import { ChartsModule } from 'ng2-charts';
import { DashboardComponent } from './dashboard.component';
import { InboxComponent } from './external/inbox/inbox.component';
import { NewInboundComponent } from './external/new-inbound/new-inbound.component';
import { InternalComponent } from './internal/internal.component';
import { ExternalComponent } from './external/external.component';

@NgModule({
  declarations: [DashboardComponent, InboxComponent, NewInboundComponent, InternalComponent, ExternalComponent],
  imports: [
    CommonModule,
    MatMenuModule,
    AppRoutingModule,
    // DashboardRoutingModule,
    MatButtonModule, 
    MatCheckboxModule,
    BrowserAnimationsModule,
    MatTableModule,
    SharableModule,
    MalihuScrollbarModule,
    MatPaginatorModule,
    ChartsModule
  ],
  schemas:[ CUSTOM_ELEMENTS_SCHEMA ],
})
export class DashboardModule { }
