import { Component, OnInit,ViewChild } from '@angular/core';
import {SelectionModel} from '@angular/cdk/collections';
import { HttpErrorResponse,HttpClient } from '@angular/common/http';
import {MatPaginator, MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  displayedColumns: string[] = ['select','ID','Subject','Requester','Type','Assigned','Received','Status','Due_Customer','options'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }
}
export interface PeriodicElement {
  ID:string,
  Subject:string,
  Requester:string,
  Type:string,
  Assigned:any,
  Received:string,
  Status:string,
  Due_Customer:string
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
  {ID: 'F17/00001012', Subject: 'Town and country planning act 1990 lorem ipsum dolor sit amet consectetur, adipisicing elit.', Requester: 'Gemma Smith', Type: 'Unknown',Assigned: [ "Luzy", "Amy Criz"],Received:'25/10/2018',Status:'Reassigned',Due_Customer:'30/10/2018'},
];