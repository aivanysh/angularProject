import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-inbound',
  templateUrl: './new-inbound.component.html',
  styleUrls: ['./new-inbound.component.scss']
})
export class NewInboundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
