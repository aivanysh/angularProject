///////////
import { Component, OnInit } from '@angular/core';
import { MatButtonModule, MatCheckboxModule } from '@angular/material';
import { HttpErrorResponse,HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-external',
  templateUrl: './external.component.html',
  styleUrls: ['./external.component.scss']
})
export class ExternalComponent implements OnInit {
  menuAction:boolean;
  internalInboundRequestsWidth:number;
  internalOutboundRequestsWidth:number;
  externalInboundRequestsWidth:number;
  externalOutboundRequestsWidth:number;
  constructor (private httpService: HttpClient) { }
  menuItems: string [];
  ngOnInit() {
    this.menuAction = false;
    this.httpService.get('../../assets/Data/menu.json').subscribe(
      data => {
        this.menuItems = data as string [];
        // console.log(this.menuItems);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
    this.internalInboundRequestsWidth = Math.floor(this.internalInboundRequests / this.totalInternalInboundRequests * 100); 
    this.internalOutboundRequestsWidth = Math.floor(this.internalOutboundRequests / this.totalInternalOutboundRequests * 100); 
    this.externalInboundRequestsWidth = Math.floor(this.externalInboundRequests / this.totalExternalInboundRequests * 100); 
    this.externalOutboundRequestsWidth = Math.floor(this.externalOutboundRequests / this.totalExternalOutboundRequests * 100); 
  }
  menuActionButton() {
    this.menuAction = !this.menuAction; 
    console.log(this.menuAction);      
  }
  //Types of requests
  // Internal Inbound
  public totalInternalInboundRequests:number = 8900;
  public internalInboundRequests:number = 7120;
  // Internal Outbound
  public totalInternalOutboundRequests:number = 8900;
  public internalOutboundRequests:number = 3120;
  // External Inbound
  public totalExternalInboundRequests:number = 900;
  public externalInboundRequests:number = 220;
  // External Outbound
  public totalExternalOutboundRequests:number = 900;
  public externalOutboundRequests:number = 880;

  // Doughnut
  public doughnutChartLabels:string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData:number[] = [350, 450, 100];
  public doughnutChartType:string = 'doughnut';
  public doughnutChartOptions:any = {
    responsive: true,
  };
  public doughnutChartColor:Array<any> = [{backgroundColor:['#8cc34b', '#36c2cf', '#a768dd']}];
}
