import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent }           from './dashboard.component';
import { ExternalComponent }    from './external/external.component';
import { NewInboundComponent }    from './external/new-inbound/new-inbound.component';
import { ExternalDashboardComponent }    from './external/external-dashboard/external-dashboard.component';
import { InternalComponent }    from './internal/internal.component';

const dashboardRoutes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [
      {
        path: '',
        children: [
          { path: 'internal', component: InternalComponent },
          { path: 'external', component: ExternalComponent,
            children: [
              {
                path: '',
                children: [
                  { path: 'new-inbounds', component: NewInboundComponent },
                  { path: '', component: ExternalDashboardComponent },
                ]
              }
            ]
          },
          { path: '',   redirectTo: '/dashboard/external', pathMatch: 'full' },
          { path: '**', redirectTo: '/dashboard/external',  component: ExternalComponent },
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(dashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DashboardRoutingModule {}
