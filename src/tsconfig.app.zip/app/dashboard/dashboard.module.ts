import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';

import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';
import { MatTooltipModule} from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule, MatCheckboxModule } from '@angular/material';
import { MatTableModule} from '@angular/material/table';
import { MatPaginatorModule} from '@angular/material/paginator';
import { ChartsModule } from 'ng2-charts';
import { DashboardRoutingModule }       from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SideNavigationComponent } from './side-navigation/side-navigation.component';
import { NewInboundComponent } from './external/new-inbound/new-inbound.component';
import { ExternalComponent } from './external/external.component';
import { InternalComponent } from './internal/internal.component';
import { ExternalDashboardComponent } from './external/external-dashboard/external-dashboard.component';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    MalihuScrollbarModule,
    MatTooltipModule,
    ChartsModule,
    MatPaginatorModule,
    MatTableModule,
    MatButtonModule,
    MatCheckboxModule,
    MatMenuModule
  ],
  declarations: [
    DashboardComponent,
    SideNavigationComponent,
    NewInboundComponent,
    ExternalComponent,
    InternalComponent,
    ExternalDashboardComponent
  ]
})
export class DashboardModule {}
