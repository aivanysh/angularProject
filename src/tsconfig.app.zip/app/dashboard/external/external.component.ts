
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { FCTSDashBoard } from '../../../environments/environment';
@Component({
  selector: 'app-external',
  templateUrl: './external.component.html'
})
export class ExternalComponent implements OnInit {
  CSUrl: String;
  menuAction: boolean = true;
  constructor(private httpService: HttpClient) { }
  menuItems: string[];
  ngOnInit() {
    this.CSUrl = CSConfig.CSUrl;
    this.httpService.get(this.CSUrl + `${FCTSDashBoard.WRApiV1}${FCTSDashBoard.getMenuCount}?Format=webreport`, {
      headers: { 'OTCSTICKET': CSConfig.AuthToken }
    }).subscribe(
      data => {
        this.menuItems = data as string[];
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }
  menuActionButton() {
    this.menuAction = !this.menuAction;
    console.log(this.menuAction);
  }
}
