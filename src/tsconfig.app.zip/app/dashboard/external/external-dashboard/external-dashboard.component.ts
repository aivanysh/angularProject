import { Component, OnInit, ViewChild } from '@angular/core';

import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { ExternalDashboardService } from './external-dashboard.service';
import { DashboardModel } from '../../dashboard.model';

@Component({
  selector: 'app-external-dashboard',
  templateUrl: './external-dashboard.component.html',
  styleUrls: ['./external-dashboard.component.scss']
})
export class ExternalDashboardComponent implements OnInit {
  internalInboundRequestsWidth: number;
  internalOutboundRequestsWidth: number;
  externalInboundRequestsWidth: number;
  externalOutboundRequestsWidth: number;
  assignedAction: boolean;
  constructor(private _externaldashobardservice: ExternalDashboardService) { }
  userData: any[];
  userDetails: string[];
  // Inbox: PeriodicElement[];
  dashBoardValues: DashboardModel[];
  displayedColumns: string[] = ['select', 'CorrespondenceCode', 'Subject', 'SubWorkTask_Title', 'FromDept', 'ToDept', 'Assigned', 'Received', 'Priority', 'Purpose', 'DueDate', 'options'];
  dataSource = new MatTableDataSource<DashboardModel>();
  selection = new SelectionModel<DashboardModel>(true, []);
  @ViewChild(MatPaginator) overviewitem: MatPaginator;
  ngOnInit() {
    this.internalInboundRequestsWidth = Math.floor(this.internalInboundRequests / this.totalInternalInboundRequests * 100);
    this.internalOutboundRequestsWidth = Math.floor(this.internalOutboundRequests / this.totalInternalOutboundRequests * 100);
    this.externalInboundRequestsWidth = Math.floor(this.externalInboundRequests / this.totalExternalInboundRequests * 100);
    this.externalOutboundRequestsWidth = Math.floor(this.externalOutboundRequests / this.totalExternalOutboundRequests * 100);


    this._externaldashobardservice.getUserData().
      subscribe((data) => this.userData = data);
  
    this._externaldashobardservice.getExternalInbNew().
      subscribe(
        (data) => this.dashBoardValues = data );
    //this.dashBoardValues = this._externaldashobardservice.getExternalInbNew();
    console.log("Sample"+this.dashBoardValues);
    this.dataSource = new MatTableDataSource<DashboardModel>(this.dashBoardValues);
    this.dataSource.paginator = this.overviewitem;

    // this.overviewitem = this.Inbox;
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  assignedActionButton() {
    this.assignedAction = !this.assignedAction;
  }
  //Types of requests
  // Internal Inbound
  public totalInternalInboundRequests: number = 8900;
  public internalInboundRequests: number = 7120;
  // Internal Outbound
  public totalInternalOutboundRequests: number = 8900;
  public internalOutboundRequests: number = 3120;
  // External Inbound
  public totalExternalInboundRequests: number = 900;
  public externalInboundRequests: number = 220;
  // External Outbound
  public totalExternalOutboundRequests: number = 900;
  public externalOutboundRequests: number = 880;

  // Doughnut
  public doughnutChartLabels: string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData: number[] = [350, 450, 100];
  public doughnutChartType: string = 'doughnut';
  public doughnutChartOptions: any = {
    responsive: true,
  };
  public doughnutChartColor: Array<any> = [{ backgroundColor: ['#8cc34b', '#36c2cf', '#a768dd'] }];
}

// const overviewitem: DashboardModel[] = this.dashBoardValues;